export const username = 'itTower'
export const password = 'itTower'
export const urlGetStudent = 'http://213.230.99.101:2027/api'
export const TOKEN_AUTH = 'token'